"""
=============================================================================
PROYECTO: ESTADÍSTICA BIVARIADA - CONSULTORA MÉDICA
SERVIDOR WEB: app.py (Flask Dashboard Gerencial)
PROPÓSITO:
  Panel de administración y auditoría estadística para el centro médico.
  Integra la lógica de:
    - 1_schema.sql (Persistencia relacional en MariaDB / MySQL)
    - 2_descriptiva.py (Análisis Descriptivo Univariado y Coeficiente de Variación)
    - 3_regresion.py (Regresión Lineal, Pearson r, R², Outliers y Predicción)
=============================================================================
"""

import os
import sys
import math
import importlib
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, flash

# Configurar encoding en Windows si aplica
if sys.platform == "win32" and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Importación dinámica de los módulos existentes (por comenzar sus nombres con dígitos)
modulo_descriptiva = importlib.import_module("2_descriptiva")
modulo_regresion = importlib.import_module("3_regresion")

# Inicialización de la aplicación Flask
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
IMG_DIR = os.path.join(STATIC_DIR, "img")

os.makedirs(IMG_DIR, exist_ok=True)
os.makedirs(TEMPLATES_DIR, exist_ok=True)

app = Flask(
    __name__,
    static_folder=STATIC_DIR,
    template_folder=TEMPLATES_DIR
)
app.config["SECRET_KEY"] = "consultora_medica_secret_key_2026_estadistica"

# Ruta para almacenar la imagen del reporte gerencial
RUTA_GRAFICO_STATIC = os.path.join(IMG_DIR, "reporte_bivariado_gerencia.png")
RUTA_GRAFICO_ROOT = os.path.join(BASE_DIR, "reporte_bivariado_gerencia.png")


def obtener_consultas_recientes(limite=15):
    """
    Obtiene los registros más recientes de consultas desde MariaDB
    para el resumen operativo del dashboard principal.
    """
    conexion = modulo_descriptiva.obtener_conexion()
    try:
        cursor = conexion.cursor()
        sql = """
        SELECT 
            c.id_consulta,
            c.edad_paciente,
            d.nombre AS medico,
            d.especialidad,
            c.anios_experiencia_doc,
            c.tiempo_atencion_min,
            c.fecha_consulta
        FROM consultas c
        JOIN doctores d ON c.id_doctor = d.id_doctor
        ORDER BY c.id_consulta DESC
        LIMIT %s;
        """
        cursor.execute(sql, (limite,))
        filas = cursor.fetchall()
        cursor.close()

        consultas = []
        for f in filas:
            consultas.append({
                "id": f[0],
                "edad": f[1],
                "medico": f[2],
                "especialidad": f[3],
                "experiencia": f[4],
                "tiempo": f[5],
                "fecha": f[6]
            })
        return consultas
    finally:
        conexion.close()


def asegurar_grafico_gerencial():
    """
    Verifica que el gráfico gerencial exista en static/img/. Si no existe,
    lo genera automáticamente utilizando la lógica de 3_regresion.py.
    """
    if not os.path.exists(RUTA_GRAFICO_STATIC):
        modulo_regresion.obtener_datos_regresion(
            generar_grafico=True,
            ruta_grafico=RUTA_GRAFICO_STATIC,
            mostrar_interactivo=False
        )
        # Sincronizar también con la raíz del proyecto para retrocompatibilidad
        try:
            import shutil
            shutil.copyfile(RUTA_GRAFICO_STATIC, RUTA_GRAFICO_ROOT)
        except Exception:
            pass


# =============================================================================
# RUTAS DE LA APLICACIÓN WEB
# =============================================================================

@app.route("/")
def index():
    """
    1. ESTRUCTURA BASE Y RESUMEN OPERATIVO DEL CENTRO MÉDICO (n = 100)
    Dashboard general con KPIs clave, estado del centro y consultas registradas.
    """
    datos_desc = modulo_descriptiva.obtener_datos_descriptivos()
    datos_reg = modulo_regresion.obtener_datos_regresion(generar_grafico=False)
    consultas_recientes = obtener_consultas_recientes(limite=15)
    asegurar_grafico_gerencial()

    total_doctores = len(datos_desc["doctores"])
    kpis = {
        "n_total": datos_desc["n_total"],
        "media_global": datos_desc["general"]["media"],
        "desviacion_global": datos_desc["general"]["desviacion"],
        "cv_global": datos_desc["general"]["cv"],
        "diagnostico_global": datos_desc["diagnostico_general"],
        "nivel_riesgo_global": datos_desc["nivel_riesgo_general"],
        "total_doctores": total_doctores,
        "r_edad": datos_reg["modelo_edad"]["r"],
        "r2_edad": datos_reg["modelo_edad"]["r2"] * 100,
        "total_outliers": len(datos_reg["outliers"]),
        "tiempo_computo_ms": datos_desc["tiempo_computo_ms"]
    }

    return render_template(
        "index.html",
        kpis=kpis,
        doctores=datos_desc["doctores"],
        consultas=consultas_recientes
    )


@app.route("/descriptiva")
def descriptiva():
    """
    2. VISTA DE ANÁLISIS DESCRIPTIVO UNIVARIADO (Problemas 1 y 3)
    Tabla comparativa de medias, desvíos y CV por doctor y especialidad.
    """
    datos = modulo_descriptiva.obtener_datos_descriptivos()
    return render_template(
        "descriptiva.html",
        datos=datos
    )


@app.route("/regresion")
def regresion():
    """
    3. VISTA DE REGRESIÓN BIVARIADA Y DETECCIÓN DE OUTLIERS (Problemas 4, 5 y 6)
    Muestra coeficientes de Pearson, R², lista detallada de anomalías
    y embebe el reporte gráfico gerencial generado.
    """
    # Siempre asegurar que el gráfico esté actualizado
    datos = modulo_regresion.obtener_datos_regresion(
        generar_grafico=True,
        ruta_grafico=RUTA_GRAFICO_STATIC,
        mostrar_interactivo=False
    )
    # Mantener copia en la raíz
    try:
        import shutil
        shutil.copyfile(RUTA_GRAFICO_STATIC, RUTA_GRAFICO_ROOT)
    except Exception:
        pass

    return render_template(
        "regresion.html",
        datos=datos,
        timestamp=int(datetime.now().timestamp())  # Para evitar caché de la imagen
    )


@app.route("/prediccion", methods=["GET", "POST"])
def prediccion():
    """
    4. MÓDULO DE PREDICCIÓN DE TURNOS INTERACTIVOS (Problema 2)
    Formulario donde el administrador ingresa la edad de un paciente y
    obtiene en tiempo real la estimación del turno y bloque sugerido de agenda.
    """
    datos_reg = modulo_regresion.obtener_datos_regresion(generar_grafico=False)
    modelo = datos_reg["modelo_edad"]
    a = modelo["a"]
    b = modelo["b"]

    resultado = None
    edad_ingresada = 45  # Valor por defecto representativo

    if request.method == "POST":
        try:
            edad_ingresada = float(request.form.get("edad_paciente", 45))
            if edad_ingresada < 0 or edad_ingresada > 120:
                flash("La edad debe encontrarse entre 0 y 120 años.", "warning")
                edad_ingresada = max(0, min(120, edad_ingresada))
            
            y_estimado, bloque = modulo_regresion.predecir_tiempo_turno(a, b, edad_ingresada)
            
            # Clasificación del perfil clínico
            if edad_ingresada < 15:
                perfil = "Pediátrico"
                badge_class = "bg-info text-dark"
            elif edad_ingresada < 35:
                perfil = "Adulto Joven"
                badge_class = "bg-primary"
            elif edad_ingresada < 60:
                perfil = "Adulto General"
                badge_class = "bg-success"
            else:
                perfil = "Adulto Mayor / Gerontológico"
                badge_class = "bg-danger"

            resultado = {
                "edad": edad_ingresada,
                "tiempo_estimado": round(y_estimado, 2),
                "bloque_agenda": bloque,
                "perfil": perfil,
                "badge_class": badge_class,
                "margen_seguridad": 5.0,
                "formula": f"ŷ = {a:.2f} + {b:.2f} × ({edad_ingresada:.0f})"
            }
        except ValueError:
            flash("Por favor ingrese un número válido para la edad.", "danger")

    return render_template(
        "prediccion.html",
        modelo=modelo,
        resultado=resultado,
        edad_inicial=edad_ingresada
    )


@app.route("/api/predecir", methods=["GET", "POST"])
def api_predecir():
    """
    Endpoint JSON para el cálculo reactivo instantáneo vía JavaScript
    en el formulario interactivo de predicción de turnos.
    """
    try:
        if request.method == "POST":
            data = request.get_json(silent=True) or request.form
            edad = float(data.get("edad", 45))
        else:
            edad = float(request.args.get("edad", 45))

        if edad < 0 or edad > 120:
            return jsonify({"error": "La edad debe estar entre 0 y 120 años."}), 400

        datos_reg = modulo_regresion.obtener_datos_regresion(generar_grafico=False)
        modelo = datos_reg["modelo_edad"]
        a = modelo["a"]
        b = modelo["b"]

        y_estimado, bloque = modulo_regresion.predecir_tiempo_turno(a, b, edad)

        if edad < 15:
            perfil = "Pediátrico"
            badge = "bg-info text-dark"
            nota = "Atención pediátrica con evaluación antropométrica y anamnesis familiar."
        elif edad < 35:
            perfil = "Adulto Joven"
            badge = "bg-primary"
            nota = "Consulta estándar para certificados, controles anuales o patologías agudas leves."
        elif edad < 60:
            perfil = "Adulto General"
            badge = "bg-success"
            nota = "Control clínico rutinario, estudios complementarios y manejo de factores de riesgo."
        else:
            perfil = "Adulto Mayor / Gerontológico"
            badge = "bg-danger"
            nota = "Atención de alta complejidad con polimedicación y múltiples comorbilidades crónicas."

        return jsonify({
            "edad": edad,
            "tiempo_estimado": round(y_estimado, 2),
            "bloque_agenda": bloque,
            "perfil": perfil,
            "badge": badge,
            "nota": nota,
            "formula": f"ŷ = {a:.2f} + {b:.2f} × ({edad:.0f})",
            "ecuacion": f"ŷ = {a:.2f} + {b:.2f}x",
            "r": round(modelo["r"], 4),
            "r2_porcentaje": round(modelo["r2"] * 100, 2)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/grafico-gerencial")
def grafico_gerencial():
    """
    Sirve la imagen del reporte gráfico de alta resolución.
    """
    asegurar_grafico_gerencial()
    return send_file(RUTA_GRAFICO_STATIC, mimetype="image/png")


# =============================================================================
# INICIALIZACIÓN DEL SERVIDOR
# =============================================================================
if __name__ == "__main__":
    print("=" * 80)
    print("  INICIANDO SERVIDOR WEB - CONSULTORA MÉDICA (FLASK)")
    print("  Acceda al Dashboard Gerencial en: http://127.0.0.1:5000")
    print("=" * 80)
    # Generar gráfico preventivamente si no existe
    asegurar_grafico_gerencial()
    app.run(host="0.0.0.0", port=5000, debug=True)
