"""
=============================================================================
PROYECTO: ESTADÍSTICA BIVARIADA - CONSULTORA MÉDICA
SCRIPT: 2_descriptiva.py
PROPÓSITO:
  Análisis Estadístico Descriptivo (Univariado) de Tiempos de Atención Médica.
  Resuelve explícitamente:
    - Problema 1: Volumen y Eficiencia (Procesamiento automatizado de n=100)
    - Problema 3: Evaluación de Desempeño y Homogeneidad (Uso del CV)
=============================================================================
"""

import math
import time
import os
import sys
import pymysql

# Asegurar codificación utf-8 en salidas de consola en Windows
if sys.platform == "win32" and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Configuración de conexión a la base de datos MariaDB
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "consultora_medica",
    "charset": "utf8mb4",
    "autocommit": True
}


def obtener_conexion():
    """
    Establece la conexión con el servidor MariaDB.
    Si la base de datos no existe o no tiene los 100 registros cargados,
    ejecuta automáticamente el archivo 1_schema.sql para garantizar
    la ejecución inmediata del entorno.
    """
    try:
        # Intento de conexión directa a la base de datos
        conexion = pymysql.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            database=DB_CONFIG["database"],
            charset=DB_CONFIG["charset"],
            autocommit=DB_CONFIG["autocommit"],
            auth_plugin_map={"auth_gssapi_client": "pymysql.credentials"}
        )
        return conexion
    except pymysql.err.OperationalError:
        # Si la base de datos no existe, conectar al servidor base y crearla
        print("[!] Base de datos 'consultora_medica' no detectada. Inicializando desde 1_schema.sql...")
        conexion_raiz = pymysql.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            charset=DB_CONFIG["charset"],
            autocommit=True,
            auth_plugin_map={"auth_gssapi_client": "pymysql.credentials"}
        )
        cursor_raiz = conexion_raiz.cursor()
        
        # Leer y ejecutar 1_schema.sql
        ruta_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "1_schema.sql")
        if os.path.exists(ruta_script):
            with open(ruta_script, "r", encoding="utf-8") as f:
                contenido_sql = f.read()
                
            # Separar y ejecutar sentencias SQL válidas
            for sentencia in contenido_sql.split(";"):
                sentencia_limpia = sentencia.strip()
                if sentencia_limpia:
                    cursor_raiz.execute(sentencia_limpia)
            print("[✓] Base de datos y 100 registros creados exitosamente.")
        else:
            raise FileNotFoundError(f"No se encontró el archivo de esquema en: {ruta_script}")
            
        cursor_raiz.close()
        conexion_raiz.close()
        
        # Reconectar ya con la base de datos creada
        return pymysql.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            database=DB_CONFIG["database"],
            charset=DB_CONFIG["charset"],
            autocommit=DB_CONFIG["autocommit"],
            auth_plugin_map={"auth_gssapi_client": "pymysql.credentials"}
        )


def calcular_estadisticas_univariadas(valores):
    """
    Calcula Media muestral, Varianza muestral, Desvío Estándar y Coeficiente de Variación.
    Fórmulas matemáticas:
      Media (x̄) = Σ x_i / n
      Varianza (s²) = Σ (x_i - x̄)² / (n - 1)
      Desvío Estándar (s) = √s²
      Coeficiente de Variación (CV) = (s / x̄) * 100 %
    """
    n = len(valores)
    if n < 2:
        return None
    
    media = sum(valores) / n
    suma_cuadrados = sum((x - media) ** 2 for x in valores)
    varianza = suma_cuadrados / (n - 1)
    desviacion = math.sqrt(varianza)
    cv = (desviacion / media) * 100.0 if media != 0 else 0.0
    
    return {
        "n": n,
        "media": media,
        "varianza": varianza,
        "desviacion": desviacion,
        "cv": cv
    }


def clasificar_homogeneidad(cv):
    """
    Interpreta el Coeficiente de Variación (CV) para auditoría de procesos hospitalarios:
      - CV < 15%: Proceso altamente homogéneo / Predecible.
      - 15% <= CV <= 30%: Variabilidad moderada / Aceptable con supervisión.
      - CV > 30%: Proceso heterogéneo / Alta dispersión o cuellos de botella.
    """
    if cv < 15.0:
        return "ALTA HOMOGENEIDAD (Excelente estabilidad operativa)", "BAJA"
    elif cv <= 30.0:
        return "VARIABILIDAD MODERADA (Aceptable, requiere monitoreo)", "MEDIA"
    else:
        return "ALTA DISPERSIÓN (Inconsistente, potencial cuello de botella)", "ALTA"


def obtener_datos_descriptivos(conexion=None):
    """
    Ejecuta el análisis descriptivo univariado completo sobre MariaDB.
    Diseñado para ser reutilizado de forma limpia tanto en el script CLI
    como en la aplicación web Flask (Dashboard Gerencial).
    """
    t_inicio = time.perf_counter()
    cerrar_conexion = False
    
    if conexion is None:
        conexion = obtener_conexion()
        cerrar_conexion = True

    try:
        cursor = conexion.cursor()

        # 1. Consulta General de Todos los Registros
        cursor.execute("SELECT id_consulta, edad_paciente, anios_experiencia_doc, tiempo_atencion_min, fecha_consulta FROM consultas ORDER BY id_consulta ASC;")
        filas_consultas = cursor.fetchall()
        tiempos_todos = [fila[3] for fila in filas_consultas]

        # 2. Consulta Agrupada por Doctor y Especialidad
        consulta_agrupada = """
        SELECT 
            d.id_doctor,
            d.nombre,
            d.especialidad,
            d.anios_experiencia,
            c.tiempo_atencion_min
        FROM consultas c
        JOIN doctores d ON c.id_doctor = d.id_doctor
        ORDER BY d.id_doctor ASC;
        """
        cursor.execute(consulta_agrupada)
        filas_doctores = cursor.fetchall()

        t_fin = time.perf_counter()
        tiempo_computo_ms = (t_fin - t_inicio) * 1000

        # Agrupar los datos por médico en memoria
        doctores_data = {}
        for id_doc, nombre, esp, exp, t_min in filas_doctores:
            clave = (id_doc, nombre, esp, exp)
            if clave not in doctores_data:
                doctores_data[clave] = []
            doctores_data[clave].append(t_min)

        stats_general = calcular_estadisticas_univariadas(tiempos_todos)
        interp_gral, nivel_riesgo_gral = clasificar_homogeneidad(stats_general["cv"]) if stats_general else ("N/D", "N/D")

        doctores_resumen = []
        for (id_doc, nombre, esp, exp), tiempos in doctores_data.items():
            st = calcular_estadisticas_univariadas(tiempos)
            if st:
                diagnostico, riesgo = clasificar_homogeneidad(st["cv"])
                doctores_resumen.append({
                    "id_doctor": id_doc,
                    "nombre": nombre,
                    "especialidad": esp,
                    "anios_experiencia": exp,
                    "n": st["n"],
                    "media": st["media"],
                    "varianza": st["varianza"],
                    "desviacion": st["desviacion"],
                    "cv": st["cv"],
                    "diagnostico": diagnostico,
                    "nivel_riesgo": riesgo
                })

        # Ordenar por CV ascendente para identificar ranking de consistencia
        doctores_ordenados = sorted(doctores_resumen, key=lambda x: x["cv"])
        doc_mas_homogeneo = doctores_ordenados[0] if doctores_ordenados else None
        doc_mas_disperso = doctores_ordenados[-1] if doctores_ordenados else None

        cursor.close()

        return {
            "n_total": len(tiempos_todos),
            "tiempo_computo_ms": tiempo_computo_ms,
            "general": stats_general,
            "diagnostico_general": interp_gral,
            "nivel_riesgo_general": nivel_riesgo_gral,
            "doctores": doctores_resumen,
            "doc_mas_homogeneo": doc_mas_homogeneo,
            "doc_mas_disperso": doc_mas_disperso
        }
    finally:
        if cerrar_conexion and conexion:
            conexion.close()


def main():
    print("=" * 80)
    print("  CONSULTORA MÉDICA - AUDITORÍA ESTADÍSTICA DESCRIPTIVA (n = 100)")
    print("  MÓDULO: ANÁLISIS DE TIEMPOS DE ATENCIÓN POR CONSULTA (min)")
    print("=" * 80)

    datos = obtener_datos_descriptivos()
    if not datos or not datos["general"]:
        print("[!] Error: No se encontraron suficientes registros en la tabla 'consultas'.")
        return

    n_total = datos["n_total"]
    tiempo_computo_ms = datos["tiempo_computo_ms"]
    stats_general = datos["general"]

    # -------------------------------------------------------------------------
    # PROBLEMA 1: VOLUMEN Y EFICIENCIA (Automatización vs Cálculo Manual)
    # -------------------------------------------------------------------------
    print("\n" + "─" * 80)
    print(f"1. RESOLUCIÓN PROBLEMA 1: VOLUMEN Y EFICIENCIA OPERATIVA")
    print("─" * 80)
    print(f" • Muestra auditada en MariaDB:              n = {n_total} consultas médicas registradas.")
    print(f" • Tiempo de procesamiento automatizado:     {tiempo_computo_ms:.2f} milisegundos.")
    print(f" • Tiempo estimado de cálculo manual humano: ~120 a 180 minutos (más de 400 operaciones).")
    print(f" • Factor de aceleración operativa:          > 100.000x más rápido, eliminando 100% de errores humanos.")

    # Informe Global
    print("\n" + "─" * 80)
    print("2. INFORME ESTADÍSTICO GENERAL DEL CENTRO MÉDICO (Tiempo de Atención en Minutos)")
    print("─" * 80)
    print(f"  Total de Pacientes Atendidos (n):        {stats_general['n']}")
    print(f"  Media Muestral (x̄):                      {stats_general['media']:.2f} minutos")
    print(f"  Varianza Muestral (s²):                  {stats_general['varianza']:.2f} min²")
    print(f"  Desviación Estándar Muestral (s):        {stats_general['desviacion']:.2f} minutos")
    print(f"  Coeficiente de Variación (CV):           {stats_general['cv']:.2f}%")
    print(f"  Diagnóstico de Variabilidad Global:      {datos['diagnostico_general']}")

    # -------------------------------------------------------------------------
    # PROBLEMA 3: EVALUACIÓN DE DESEMPEÑO Y HOMOGENEIDAD POR DOCTOR
    # -------------------------------------------------------------------------
    print("\n" + "─" * 80)
    print("3. RESOLUCIÓN PROBLEMA 3: HOMOGENEIDAD Y DESEMPEÑO POR DOCTOR/ESPECIALIDAD")
    print("   (Uso del Coeficiente de Variación para comparación justa de variabilidad)")
    print("─" * 80)
    print(f"{'Médico':<23} | {'Especialidad':<18} | {'Exp':>4} | {'n':>3} | {'x̄ (min)':>7} | {'s (min)':>7} | {'CV (%)':>7} | {'Homogeneidad'}")
    print("─" * 115)

    for doc in datos["doctores"]:
        print(f"{doc['nombre']:<23} | {doc['especialidad']:<18} | {doc['anios_experiencia']:>3}a | {doc['n']:>3} | {doc['media']:>7.2f} | {doc['desviacion']:>7.2f} | {doc['cv']:>6.2f}% | {doc['diagnostico']}")

    print("─" * 115)

    doc_mas_homogeneo = datos["doc_mas_homogeneo"]
    doc_mas_disperso = datos["doc_mas_disperso"]

    print("\n► CONCLUSIONES DE GESTIÓN CLÍNICA (Problema 3):")
    if doc_mas_homogeneo:
        print(f"  • Mayor Homogeneidad: {doc_mas_homogeneo['nombre']} ({doc_mas_homogeneo['especialidad']}) con un CV de {doc_mas_homogeneo['cv']:.2f}%.")
        print(f"    Sus tiempos de consulta son altamente predecibles y facilitan una programación de agenda sin demoras.")
    if doc_mas_disperso:
        print(f"  • Mayor Variabilidad: {doc_mas_disperso['nombre']} ({doc_mas_disperso['especialidad']}) con un CV de {doc_mas_disperso['cv']:.2f}%.")
        print(f"    Sus tiempos son heterogéneos; se recomienda auditar si atiende patologías de complejidad dispar")
        print(f"    o si requiere reasignación en bloques dinámicos de agenda.")

    print("\n" + "=" * 80)
    print("  FIN DEL REPORTE DESCRIPTIVO. Ejecute 'python 3_regresion.py' para el modelo bivariado.")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()
