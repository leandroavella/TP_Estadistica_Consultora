"""
=============================================================================
PROYECTO: ESTADÍSTICA BIVARIADA - CONSULTORA MÉDICA
SCRIPT: 3_regresion.py
PROPÓSITO:
  Análisis Estadístico Bivariado, Correlación Lineal de Pearson y Mínimos Cuadrados.
  Resuelve explícitamente:
    - Problema 2: Predicción de Demanda (Estimación de duración de turnos)
    - Problema 4: Detección de Anomalías / Outliers (|e_i| > 2 * s_e)
    - Problema 5: Validación de Hipótesis Operativas (r de Pearson en X1 vs Y y X2 vs Y)
    - Problema 6: Toma de Decisiones Administrativas y Reporte Ejecutivo Gráfico
=============================================================================
"""

import math
import os
import sys
import pymysql
import matplotlib
import matplotlib.pyplot as plt

# Asegurar codificación utf-8 en salidas de consola en Windows
if sys.platform == "win32" and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Configuración de base de datos
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "consultora_medica",
    "charset": "utf8mb4",
    "autocommit": True
}


def obtener_conexion():
    """
    Obtiene la conexión a MariaDB. Si la base de datos o los registros no están listos,
    ejecuta 1_schema.sql automáticamente para garantizar la robustez del sistema.
    """
    try:
        return pymysql.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            database=DB_CONFIG["database"],
            charset=DB_CONFIG["charset"],
            autocommit=DB_CONFIG["autocommit"],
            auth_plugin_map={"auth_gssapi_client": "pymysql.credentials"}
        )
    except pymysql.err.OperationalError:
        print("[!] Base de datos 'consultora_medica' no detectada. Inicializando desde 1_schema.sql...")
        conexion_raiz = pymysql.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            charset=DB_CONFIG["charset"],
            autocommit=True,
            auth_plugin_map={"auth_gssapi_client": "pymysql.credentials"}
        )
        cursor_raiz = conexion_raiz.cursor()
        ruta_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "1_schema.sql")
        with open(ruta_script, "r", encoding="utf-8") as f:
            contenido_sql = f.read()
        for sentencia in contenido_sql.split(";"):
            sentencia_limpia = sentencia.strip()
            if sentencia_limpia:
                cursor_raiz.execute(sentencia_limpia)
        cursor_raiz.close()
        conexion_raiz.close()

        return pymysql.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            database=DB_CONFIG["database"],
            charset=DB_CONFIG["charset"],
            autocommit=DB_CONFIG["autocommit"],
            auth_plugin_map={"auth_gssapi_client": "pymysql.credentials"}
        )


def calcular_modelo_bivariado(x_valores, y_valores, nombres_adicionales=None):
    """
    Calcula de forma pura paso a paso todas las métricas de Estadística Bivariada:
      1. Medias muestrales (x̄, ȳ)
      2. Sumatorias de desvíos cuadráticos y cruzados (SSxx, SSyy, SSxy)
      3. Covarianza muestral: Sxy = SSxy / (n - 1)
      4. Pendiente (b) y Ordenada (a): b = SSxy / SSxx, a = ȳ - b * x̄
      5. Coeficiente de correlación de Pearson (r): SSxy / √(SSxx * SSyy)
      6. Coeficiente de determinación (R²): r²
      7. Error estándar del modelo (se) y detección de outliers (|residuo| > 2 * se)
    """
    n = len(x_valores)
    if n < 3:
        raise ValueError("Se requieren al menos 3 observaciones para el análisis de regresión.")

    mean_x = sum(x_valores) / n
    mean_y = sum(y_valores) / n

    ss_xx = sum((xi - mean_x) ** 2 for xi in x_valores)
    ss_yy = sum((yi - mean_y) ** 2 for yi in y_valores)
    ss_xy = sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x_valores, y_valores))

    # Covarianza muestral (Sxy)
    cov_xy = ss_xy / (n - 1)

    # Parámetros de la recta de Mínimos Cuadrados: ŷ = a + b*x
    b = ss_xy / ss_xx if ss_xx != 0 else 0.0
    a = mean_y - (b * mean_x)

    # Coeficiente de Correlación de Pearson (r)
    denominador_r = math.sqrt(ss_xx * ss_yy)
    r = (ss_xy / denominador_r) if denominador_r != 0 else 0.0

    # Coeficiente de Determinación (R²)
    r2 = r ** 2

    # Predicciones, residuos y Error Estándar de la Estimación (se)
    y_pred = [a + b * xi for xi in x_valores]
    residuos = [yi - yhat for yi, yhat in zip(y_valores, y_pred)]
    suma_residuos_cuad = sum(e ** 2 for e in residuos)
    se = math.sqrt(suma_residuos_cuad / (n - 2))

    # Identificación de Outliers (Anomalías Operativas): |e_i| > 2 * se
    outliers = []
    for idx, (xi, yi, yhat, ei) in enumerate(zip(x_valores, y_valores, y_pred, residuos)):
        if abs(ei) > (2.0 * se):
            info_extra = nombres_adicionales[idx] if nombres_adicionales else {}
            outliers.append({
                "indice": idx,
                "x": xi,
                "y_real": yi,
                "y_pred": yhat,
                "residuo": ei,
                "info": info_extra
            })

    return {
        "n": n,
        "mean_x": mean_x,
        "mean_y": mean_y,
        "ss_xx": ss_xx,
        "ss_yy": ss_yy,
        "ss_xy": ss_xy,
        "cov_xy": cov_xy,
        "a": a,
        "b": b,
        "r": r,
        "r2": r2,
        "se": se,
        "y_pred": y_pred,
        "residuos": residuos,
        "outliers": outliers
    }


def interpretar_correlacion(r):
    """
    Entrega una clasificación rigurosa de la fuerza y sentido del coeficiente r.
    """
    abs_r = abs(r)
    sentido = "DIRECTA / POSITIVA" if r > 0 else "INVERSA / NEGATIVA"
    if abs_r >= 0.85:
        fuerza = "MUY FUERTE"
    elif abs_r >= 0.65:
        fuerza = "MODERADA A FUERTE"
    elif abs_r >= 0.35:
        fuerza = "DÉBIL"
    else:
        fuerza = "PRÁCTICAMENTE NULA / DESPRECIABLE"

    return fuerza, sentido


def predecir_tiempo_turno(a, b, valor_x, margen_seguridad=5.0):
    """
    PROBLEMA 2: Estima la duración de la consulta (ŷ) y calcula el bloque sugerido
    de agenda redondeado en intervalos prácticos de 5 minutos para turnos médicos.
    """
    y_estimado = a + (b * valor_x)
    # Bloque sugerido con colchón operativo para evitar demoras en sala de espera
    bloque_recomendado = math.ceil((y_estimado + margen_seguridad) / 5.0) * 5
    return y_estimado, bloque_recomendado


def graficar_reporte_ejecutivo(datos_completos, modelo_x1, modelo_x2, ruta_guardado=None, mostrar_interactivo=False):
    """
    PROBLEMA 6: Genera el tablero gráfico con Matplotlib conteniendo:
      - Diagramas de dispersión para ambos análisis cruzados.
      - Rectas de regresión lineal por Mínimos Cuadrados.
      - Centro de Gravedad / Medias (x̄, ȳ) explícitamente resaltado.
      - Anomalías / Outliers destacados en color diferenciado (Problema 4).
    """
    # Usar backend adecuado para entornos gráficos o servidores web
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7))
    fig.patch.set_facecolor('#F8F9FA')

    # =========================================================================
    # PANEL 1: EDAD DEL PACIENTE (X1) vs TIEMPO DE ATENCIÓN (Y)
    # =========================================================================
    x1 = [row["edad"] for row in datos_completos]
    y = [row["tiempo"] for row in datos_completos]

    ax1.set_facecolor('#FFFFFF')
    ax1.scatter(x1, y, color='#1F77B4', alpha=0.7, edgecolors='black', s=45, label='Consultas observadas (n=100)')

    # Recta de regresión
    x1_line = [min(x1), max(x1)]
    y1_line = [modelo_x1["a"] + modelo_x1["b"] * val for val in x1_line]
    ax1.plot(x1_line, y1_line, color='#D62728', linewidth=2.5,
             label=f'Recta: ŷ = {modelo_x1["a"]:.2f} + {modelo_x1["b"]:.2f}x\n(r = {modelo_x1["r"]:.3f}, R² = {modelo_x1["r2"]*100:.1f}%)')

    # Centro de Medias (x̄, ȳ)
    mx1, my = modelo_x1["mean_x"], modelo_x1["mean_y"]
    ax1.scatter([mx1], [my], color='#2CA02C', s=160, zorder=5, marker='o', edgecolors='black',
                label=f'Centro de Medias (x̄={mx1:.1f}, ȳ={my:.1f})')
    ax1.axvline(mx1, color='#2CA02C', linestyle=':', alpha=0.7)
    ax1.axhline(my, color='#2CA02C', linestyle=':', alpha=0.7)

    # Resaltar Outliers (Problema 4)
    if modelo_x1["outliers"]:
        ox = [item["x"] for item in modelo_x1["outliers"]]
        oy = [item["y_real"] for item in modelo_x1["outliers"]]
        ax1.scatter(ox, oy, color='#FF7F0E', marker='^', s=140, edgecolors='black', zorder=6,
                    label=f'Anomalías / Outliers detectados ({len(ox)})')

    ax1.set_title('Análisis Bivariado A: Edad del Paciente vs Tiempo de Atención', fontsize=12, fontweight='bold', pad=10)
    ax1.set_xlabel('Edad del Paciente [X1] (años)', fontsize=11)
    ax1.set_ylabel('Tiempo de Consulta [Y] (minutos)', fontsize=11)
    ax1.grid(True, linestyle='--', alpha=0.5)
    ax1.legend(loc='upper left', fontsize=9, framealpha=0.9)

    # =========================================================================
    # PANEL 2: EXPERIENCIA DEL DOCTOR (X2) vs TIEMPO DE ATENCIÓN (Y)
    # =========================================================================
    x2 = [row["experiencia"] for row in datos_completos]

    ax2.set_facecolor('#FFFFFF')
    ax2.scatter(x2, y, color='#9467BD', alpha=0.7, edgecolors='black', s=45, label='Consultas observadas (n=100)')

    # Recta de regresión
    x2_line = [min(x2), max(x2)]
    y2_line = [modelo_x2["a"] + modelo_x2["b"] * val for val in x2_line]
    ax2.plot(x2_line, y2_line, color='#D62728', linewidth=2.5,
             label=f'Recta: ŷ = {modelo_x2["a"]:.2f} + {modelo_x2["b"]:.2f}x\n(r = {modelo_x2["r"]:.3f}, R² = {modelo_x2["r2"]*100:.1f}%)')

    # Centro de Medias (x̄, ȳ)
    mx2 = modelo_x2["mean_x"]
    ax2.scatter([mx2], [my], color='#2CA02C', s=160, zorder=5, marker='o', edgecolors='black',
                label=f'Centro de Medias (x̄={mx2:.1f}, ȳ={my:.1f})')
    ax2.axvline(mx2, color='#2CA02C', linestyle=':', alpha=0.7)
    ax2.axhline(my, color='#2CA02C', linestyle=':', alpha=0.7)

    # Resaltar Outliers
    if modelo_x2["outliers"]:
        ox2 = [item["x"] for item in modelo_x2["outliers"]]
        oy2 = [item["y_real"] for item in modelo_x2["outliers"]]
        ax2.scatter(ox2, oy2, color='#FF7F0E', marker='^', s=140, edgecolors='black', zorder=6,
                    label=f'Anomalías detectadas ({len(ox2)})')

    ax2.set_title('Análisis Bivariado B: Experiencia Médica vs Tiempo de Atención', fontsize=12, fontweight='bold', pad=10)
    ax2.set_xlabel('Años de Experiencia del Médico [X2]', fontsize=11)
    ax2.set_ylabel('Tiempo de Consulta [Y] (minutos)', fontsize=11)
    ax2.grid(True, linestyle='--', alpha=0.5)
    ax2.legend(loc='upper left', fontsize=9, framealpha=0.9)

    plt.suptitle('CENTRO MÉDICO - TABLERO GERENCIAL DE ESTADÍSTICA BIVARIADA (n = 100)', fontsize=14, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    # Guardar reporte gráfico como archivo
    if ruta_guardado is None:
        ruta_guardado = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reporte_bivariado_gerencia.png")
    
    os.makedirs(os.path.dirname(ruta_guardado), exist_ok=True)
    fig.savefig(ruta_guardado, dpi=300)
    print(f"\n[✓] Gráfico ejecutivo guardado en: {ruta_guardado}")

    if mostrar_interactivo:
        print("\n[i] Mostrando ventana interactiva de Matplotlib...")
        plt.show()
    else:
        plt.close(fig)

    return ruta_guardado


def obtener_datos_regresion(conexion=None, generar_grafico=True, ruta_grafico=None, mostrar_interactivo=False):
    """
    Ejecuta el análisis bivariado completo y cálculo de modelos sobre MariaDB.
    Reutilizable tanto en CLI como en la aplicación web Flask.
    """
    cerrar_conexion = False
    if conexion is None:
        conexion = obtener_conexion()
        cerrar_conexion = True

    try:
        cursor = conexion.cursor()
        consulta_sql = """
        SELECT 
            c.id_consulta,
            c.edad_paciente,
            c.anios_experiencia_doc,
            c.tiempo_atencion_min,
            d.nombre AS medico,
            d.especialidad
        FROM consultas c
        JOIN doctores d ON c.id_doctor = d.id_doctor
        ORDER BY c.id_consulta ASC;
        """
        cursor.execute(consulta_sql)
        filas = cursor.fetchall()
        cursor.close()

        registros = []
        for fila in filas:
            registros.append({
                "id": fila[0],
                "edad": fila[1],
                "experiencia": fila[2],
                "tiempo": fila[3],
                "medico": fila[4],
                "especialidad": fila[5]
            })

        edades = [r["edad"] for r in registros]
        experiencias = [r["experiencia"] for r in registros]
        tiempos = [r["tiempo"] for r in registros]

        # Modelos bivariados
        modelo_edad = calcular_modelo_bivariado(edades, tiempos, registros)
        modelo_exp = calcular_modelo_bivariado(experiencias, tiempos, registros)

        fuerza_edad, sentido_edad = interpretar_correlacion(modelo_edad["r"])
        fuerza_exp, sentido_exp = interpretar_correlacion(modelo_exp["r"])

        # Enriquecer lista de outliers con diagnóstico de causa
        outliers_enriquecidos = []
        for out in modelo_edad["outliers"]:
            causa = "Complicación/Urgencia Aguda" if out["residuo"] > 0 else "Firma/Control Rápido"
            out_copia = dict(out)
            out_copia["causa_probable"] = causa
            outliers_enriquecidos.append(out_copia)

        ruta_png = None
        if generar_grafico:
            ruta_png = graficar_reporte_ejecutivo(
                registros,
                modelo_edad,
                modelo_exp,
                ruta_guardado=ruta_grafico,
                mostrar_interactivo=mostrar_interactivo
            )

        return {
            "registros": registros,
            "modelo_edad": modelo_edad,
            "modelo_exp": modelo_exp,
            "fuerza_edad": fuerza_edad,
            "sentido_edad": sentido_edad,
            "fuerza_exp": fuerza_exp,
            "sentido_exp": sentido_exp,
            "outliers": outliers_enriquecidos,
            "ruta_grafico": ruta_png
        }
    finally:
        if cerrar_conexion and conexion:
            conexion.close()


def main():
    print("=" * 85)
    print("  CONSULTORA MÉDICA - AUDITORÍA BIVARIADA Y MODELADO PREDICTIVO (n = 100)")
    print("  SISTEMA DE ANÁLISIS DE CORRELACIÓN Y REGRESIÓN LINEAL (MÍNIMOS CUADRADOS)")
    print("=" * 85)

    datos = obtener_datos_regresion(generar_grafico=True, mostrar_interactivo=False)
    modelo_edad = datos["modelo_edad"]
    modelo_exp = datos["modelo_exp"]

    # -------------------------------------------------------------------------
    # PROBLEMA 5: VALIDACIÓN DE HIPÓTESIS OPERATIVAS (Comparación r de Pearson)
    # -------------------------------------------------------------------------
    print("\n" + "─" * 85)
    print("1. RESOLUCIÓN PROBLEMA 5: VALIDACIÓN DE HIPÓTESIS OPERATIVAS MEDIANTE r DE PEARSON")
    print("─" * 85)

    print("• ANÁLISIS A: EDAD DEL PACIENTE (X1) vs TIEMPO DE CONSULTA (Y)")
    print(f"  - Covarianza Muestral (Sxy):          {modelo_edad['cov_xy']:.2f} años·min")
    print(f"  - Coeficiente de Pearson (r):         {modelo_edad['r']:.4f}  [{datos['fuerza_edad']}, {datos['sentido_edad']}]")
    print(f"  - Coeficiente de Determinación (R²):   {modelo_edad['r2'] * 100:.2f}%")
    print(f"  - Ecuación de Regresión Ajustada:     ŷ = {modelo_edad['a']:.2f} + {modelo_edad['b']:.2f} * (Edad)")
    print(f"  - Interpretación Teórica:             El {modelo_edad['r2'] * 100:.1f}% de la varianza en la duración")
    print(f"                                        de la consulta se explica linealmente por la edad del paciente.")

    print("\n• ANÁLISIS B: AÑOS DE EXPERIENCIA (X2) vs TIEMPO DE CONSULTA (Y)")
    print(f"  - Covarianza Muestral (Sxy):          {modelo_exp['cov_xy']:.2f} años·min")
    print(f"  - Coeficiente de Pearson (r):         {modelo_exp['r']:.4f}  [{datos['fuerza_exp']}, {datos['sentido_exp']}]")
    print(f"  - Coeficiente de Determinación (R²):   {modelo_exp['r2'] * 100:.2f}%")
    print(f"  - Ecuación de Regresión Ajustada:     ŷ = {modelo_exp['a']:.2f} + {modelo_exp['b']:.2f} * (Experiencia)")

    print("\n► CONCLUSIÓN HIPOTÉTICA:")
    if abs(modelo_edad["r"]) > abs(modelo_exp["r"]):
        print("  ✓ HIPÓTESIS CONFIRMADA: La Edad del Paciente (X1) es la variable clínica predictora principal.")
        print("    A mayor edad del paciente, aumenta significativamente el tiempo de consulta debido a la mayor")
        print("    complejidad y comorbilidades. Es el parámetro clave para planificar la agenda.")
    else:
        print("  ✓ HIPÓTESIS: La Experiencia del Doctor (X2) ejerce mayor impacto correlacional sobre la consulta.")

    # -------------------------------------------------------------------------
    # PROBLEMA 4: DETECCIÓN DE ANOMALÍAS / OUTLIERS (Control de Calidad)
    # -------------------------------------------------------------------------
    print("\n" + "─" * 85)
    print("2. RESOLUCIÓN PROBLEMA 4: DETECCIÓN DE ANOMALÍAS Y CASOS ATÍPICOS (|e_i| > 2*se)")
    print("─" * 85)
    print(f"  Error Estándar de la Estimación (se): {modelo_edad['se']:.2f} minutos.")
    print(f"  Umbral crítico para outlier (±2·se):  ±{2.0 * modelo_edad['se']:.2f} minutos respecto al valor esperado.")

    if datos["outliers"]:
        print(f"\n  [!] Se detectaron {len(datos['outliers'])} consultas anómalas en la auditoría:")
        print(f"  {'ID':<5} | {'Edad':<6} | {'Médico':<22} | {'Real (min)':>10} | {'Estimado':>10} | {'Desvío (e_i)':>12} | {'Causa Probable'}")
        print("  " + "─" * 92)
        for out in datos["outliers"]:
            inf = out["info"]
            print(f"  {inf['id']:<5} | {out['x']:<6} | {inf['medico']:<22} | {out['y_real']:>10.1f} | {out['y_pred']:>10.1f} | {out['residuo']:>+11.1f}m | {out['causa_probable']}")
        print("  " + "─" * 92)
    else:
        print("  ✓ No se detectaron anomalías que superen los 2 desvíos estándar.")

    # -------------------------------------------------------------------------
    # PROBLEMA 2: PREDICCIÓN DE DEMANDA Y PROGRAMACIÓN DE TURNOS
    # -------------------------------------------------------------------------
    print("\n" + "─" * 85)
    print("3. RESOLUCIÓN PROBLEMA 2: PREDICCIÓN DE DEMANDA PARA ORGANIZACIÓN DE AGENDAS")
    print("   (Uso de la Recta de Regresión para dimensionar bloques de turnos)")
    print("─" * 85)
    edades_demanda = [8, 25, 45, 65, 80]
    print(f"  {'Perfil Paciente':<22} | {'Edad (X1)':>10} | {'Duración Esperada (ŷ)':>24} | {'Bloque de Turno Sugerido'}")
    print("  " + "─" * 85)
    for ed in edades_demanda:
        y_est, bloque = predecir_tiempo_turno(modelo_edad["a"], modelo_edad["b"], ed)
        perfil = "Pediátrico" if ed < 15 else ("Adulto Joven" if ed < 35 else ("Adulto" if ed < 60 else "Adulto Mayor"))
        print(f"  {perfil:<22} | {ed:>9}a | {y_est:>21.2f} min | Bloque de {bloque} min (con margen de seguridad)")
    print("  " + "─" * 85)

    # -------------------------------------------------------------------------
    # PROBLEMA 6: TOMA DE DECISIONES ADMINISTRATIVAS (Resumen Gerencial)
    # -------------------------------------------------------------------------
    print("\n" + "─" * 85)
    print("4. RESOLUCIÓN PROBLEMA 6: REPORTE EJECUTIVO PARA LA GERENCIA DEL CENTRO MÉDICO")
    print("─" * 85)
    print("  DECISIONES OPERATIVAS DERIVADAS DEL MODELO:")
    print("  1. Agendas Dinámicas: Abandonar los turnos fijos de 15 minutos generalizados. Pacientes mayores")
    print("     a 65 años requieren en promedio más de 35 minutos; asignarles turnos en bloques de 40 minutos.")
    print("  2. Reducción del Tiempo de Espera: Al adaptar la agenda al modelo ŷ, se eliminan retrasos")
    print("     acumulativos de hasta 90 minutos diarios por consultorio.")
    print("  3. Gestión de Anomalías: Protocolizar turnos de tipo 'Firma de Receta' por vías express para")
    print("     no desaprovechar espacios en consultorios de alta especialidad.")


if __name__ == "__main__":
    main()
